import py_compile
import unittest
from gradescope_utils.autograder_utils.decorators import weight, number
from queens import prettyPrint

class TestEx1(unittest.TestCase):
  @weight(1)
  @number("4.1")
  def test_1(self):
    """1x1 board"""
    board = [0]
    desired_val = ["Q"]
    val = prettyPrint(board)
    self.assertEqual(val, desired_val)

  @weight(1)
  @number("4.2")
  def test_2(self):
    """4x4 board 1"""
    board = [1, 3, 0, 2]
    desired_val = [". . Q .",
                   "Q . . .",
                   ". . . Q",
                   ". Q . ."]
    val = prettyPrint(board)
    self.assertEqual(val, desired_val)

  @weight(1)
  @number("4.3")
  def test_3(self):
    """4x4 board 2"""
    board = [2, 0, 3, 1]
    desired_val = [". Q . .",
                   ". . . Q",
                   "Q . . .",
                   ". . Q ."]
    val = prettyPrint(board)
    self.assertEqual(val, desired_val)

  # @weight(1)
  # @number("4.3")
  # def test_3(self):
  #   """6x6 board"""
  #   board = [3, 0, 4, 1, 5, 2]
  #   desired_val = (". Q . . . .\n"
  #                  ". . . Q . .\n"
  #                  ". . . . . Q\n"
  #                  "Q . . . . .\n"
  #                  ". . Q . . .\n"
  #                  ". . . . Q .\n")
  #   val = prettyPrint(board)
  #   self.assertEqual(val, desired_val)

  # @weight(1)
  # @number("4.4")
  # def test_4(self):
  #   """8x8 board 1"""
  #   board = [2, 4, 7, 3, 0, 6, 1, 5]
  #   desired_val = (". . . . Q . . .\n"
  #                  ". . . . . . Q .\n"
  #                  "Q . . . . . . .\n"
  #                  ". . . Q . . . .\n"
  #                  ". Q . . . . . .\n"
  #                  ". . . . . . . Q\n"
  #                  ". . . . . Q . .\n"
  #                  ". . Q . . . . .\n")
  #   val = prettyPrint(board)
  #   self.assertEqual(val, desired_val)

  @weight(1)
  @number("4.4")
  def test_4(self):
    """8x8 board"""
    board = [7, 1, 3, 0, 6, 4, 2, 5]
    desired_val = [". . . Q . . . .",
                   ". Q . . . . . .",
                   ". . . . . . Q .",
                   ". . Q . . . . .",
                   ". . . . . Q . .",
                   ". . . . . . . Q",
                   ". . . . Q . . .",
                   "Q . . . . . . ."]
    val = prettyPrint(board)
    self.assertEqual(val, desired_val)

  @weight(1)
  @number("4.5")
  def test_5(self):
    """15x15 board - odd size and large board"""
    board = [5, 0, 6, 4, 11, 14, 3, 13, 8, 12, 2, 7, 10, 1, 9]
    desired_val = [". Q . . . . . . . . . . . . .",
                   ". . . . . . . . . . . . . Q .",
                   ". . . . . . . . . . Q . . . .",
                   ". . . . . . Q . . . . . . . .",
                   ". . . Q . . . . . . . . . . .",
                   "Q . . . . . . . . . . . . . .",
                   ". . Q . . . . . . . . . . . .",
                   ". . . . . . . . . . . Q . . .",
                   ". . . . . . . . Q . . . . . .",
                   ". . . . . . . . . . . . . . Q",
                   ". . . . . . . . . . . . Q . .",
                   ". . . . Q . . . . . . . . . .",
                   ". . . . . . . . . Q . . . . .",
                   ". . . . . . . Q . . . . . . .",
                   ". . . . . Q . . . . . . . . ."]
    val = prettyPrint(board)
    self.assertEqual(val, desired_val)