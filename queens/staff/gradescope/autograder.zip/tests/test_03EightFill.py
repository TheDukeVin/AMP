import py_compile
import unittest
from gradescope_utils.autograder_utils.decorators import weight, number
from queens import EightQueens_fill

def noConflicts(board, current):
  for i in range(current):
    if (board[i] == board[current]):
      return False
    if (current - i == abs(board[current] - board[i])):
      return False
  return True

def testValid(board, inp):
  if board == None:
    return False
  if len(board) != len(inp):
    return False
  for i in range(len(board)):
    if inp[i] >= 0 and board[i] != inp[i] or 0 > board[i] or len(board) <= board[i]:
      return False
  for i in range(len(board)):
    if not noConflicts(board, i):
      return False
  return True

class TestEx1(unittest.TestCase):
  @weight(1)
  @number("3.1")
  def test_1(self):
    """8x8 empty"""
    board = [-1, -1, -1, -1, -1, -1, -1, -1]
    val = testValid(EightQueens_fill(board), board)
    self.assertEqual(val, True)

  @weight(1)
  @number("3.2")
  def test_2(self):
    """8x8 filled one"""
    board = [-1, -1, -1, -1, -1, -1, -1, 0]
    val = testValid(EightQueens_fill(board), board)
    self.assertEqual(val, True)

  @weight(1)
  @number("3.3")
  def test_3(self):
    """8x8 filled two"""
    board = [-1, -1, -1, 2, -1, 3, -1, -1]
    val = testValid(EightQueens_fill(board), board)
    self.assertEqual(val, True)

  @weight(1)
  @number("3.4")
  def test_4(self):
    """8x8 filled four"""
    board = [-1, 5, -1, 2, -1, 3, 6, -1]
    val = testValid(EightQueens_fill(board), board)
    self.assertEqual(val, True)

  @weight(1)
  @number("3.5")
  def test_5(self):
    """8x8 filled all"""
    board = [6, 1, 5, 2, 0, 3, 7, 4]
    val = testValid(EightQueens_fill(board), board)
    self.assertEqual(val, True)

  @weight(1)
  @number("3.6")
  def test_6(self):
    """8x8 invalid filled - already full and wrong"""
    board = [6, 1, 5, 2, 0, 4, 7, 3]
    val = EightQueens_fill(board)
    self.assertEqual(val, None)

  @weight(1)
  @number("3.7")
  def test_7(self):
    """8x8 invalid filled - filled six wrong"""
    board = [-1, -1, 5, -1, 0, 4, -1, 3]
    val = EightQueens_fill(board)
    self.assertEqual(val, None)

  @weight(1)
  @number("3.8")
  def test_8(self):
    """8x8 invalid filled - filled two wrong"""
    board = [-1, -1, 1, 2, -1, -1, -1, -1]
    val = EightQueens_fill(board)
    self.assertEqual(val, None)

  @weight(1)
  @number("3.9")
  def test_9(self):
    """8x8 invalid filled - column out of bounds"""
    board = [8, -1, -1, -1, -1, -1, -1, -1]
    val = EightQueens_fill(board)
    self.assertEqual(val, None)
